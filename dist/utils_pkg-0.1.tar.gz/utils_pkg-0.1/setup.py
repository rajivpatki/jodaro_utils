from setuptools import setup

setup(name='utils_pkg',
      version='0.1',
      packages=["utils_pkg"])
      